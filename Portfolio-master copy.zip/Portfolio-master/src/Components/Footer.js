import React from 'react'
import '../Styles/Footer.css'



function Footer() {
    return (
      <footer>
        <div className="footer-content">
          <p>&copy;Copyright ©2023. Designed by Adam. </p>
        </div>
      </footer>
    );
  }
  
  export default Footer;
  